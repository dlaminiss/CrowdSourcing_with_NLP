from django.apps import AppConfig


class StudentlifeConfig(AppConfig):
    name = 'studentlife'
