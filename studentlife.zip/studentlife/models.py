from django.db import models
from django.core.urlresolvers import reverse
from datetime import date
from django.utils import timezone

class CuisineShops(models.Model):
    shop_name = models.CharField(max_length=100, primary_key=True) #a combination of shopname + address
    geo_lon = models.CharField(max_length=15)
    geo_lat = models.CharField(max_length=15)
    post_code = models.CharField(max_length=10)
    shop_address = models.CharField(max_length=100)
    shop_street =  models.CharField(max_length=100)

class CuisineComments(models.Model):
    cuisine_name = models.CharField(max_length=100)
    shop_name = models.ForeignKey('CuisineShops')
    comments = models.CharField(max_length=1000)
    town_name = models.CharField(max_length=100)

#class OntologyTable(models.Model):
class TourPlaces(models.Model):
    MY_CHOICES = (
        ('1', 'Art'),
        ('2', 'Architecture'),
        ('3', 'Cultural monuments'),
        ('4', 'Food and drink'),
        ('5', 'Historical site'),
        ('6', 'Local traditions'),
        ('7', 'Museums'),
        ('8', 'Music and drama'),
        ('9', 'Parks'),
    )
    place_name = models.CharField(max_length=100, primary_key=True)
    full_address = models.CharField(max_length=100)
    place_type = models.CharField(max_length=1, choices=MY_CHOICES)
    geo_lon = models.CharField(max_length=15)
    geo_lat = models.CharField(max_length=15)
    post_code = models.CharField(max_length=10)


class TourComments(models.Model):
    place_name = models.ForeignKey(
        'TourPlaces',
        on_delete=models.CASCADE,
    )
    comments = models.CharField(max_length=1000)
    sentiments = models.DecimalField(decimal_places=2,max_digits=5)
    town_name = models.CharField(max_length=100)
    entry_price = models.DecimalField(decimal_places=2,max_digits=5)


class Universities(models.Model):
    university_name = models.CharField(max_length=100, primary_key=True)
    national_ranking = models.IntegerField()
    town = models.CharField(max_length=100)
    def __str__(self):              # __unicode__ on Python 2
        return "%s" % (self.university_name)


class UniHallsRatings(models.Model):
    hall_name = models.CharField(max_length=100)
    university_name = models.ForeignKey(
        'Universities',
        on_delete=models.CASCADE,
    )
    comments =  models.CharField(max_length=1000)
    value_for_money = models.DecimalField(decimal_places=2,max_digits=5)
    cleanness = models.DecimalField(decimal_places=2,max_digits=5)
    internet = models.DecimalField(decimal_places=2,max_digits=5)
    social = models.DecimalField(decimal_places=2,max_digits=5)
    location = models.DecimalField(decimal_places=2,max_digits=5)
    commentSentiment = models.DecimalField(decimal_places=2,max_digits=5)

class UniHalls(models.Model):
    MY_CHOICES = (
        ('1', 'Postgraduate'),
        ('2', 'Undergraduate'),
        ('3', 'All'),
    )
    ROOM_TYPE = (
        ('1', 'Ensuite'),
        ('2', 'Shared bathroom'),
    )
    hall_name = models.CharField(max_length=100, primary_key = True)
    university_name = models.ForeignKey(
        'Universities',
        on_delete=models.CASCADE,
    )
    price = models.DecimalField(decimal_places=2,max_digits=10)
    website = models.URLField()
    audience = models.CharField(max_length=1, choices=MY_CHOICES)
    roomtype = models.CharField(max_length=1, choices=ROOM_TYPE)
    period_start = models.DateField(default=date.today)
    period_end = models.DateField(default=date.today)
    
class Db1(models.Model):
    name = models.CharField(max_length=100, primary_key=True)
    surname = models.CharField(max_length=100)

class Db2(models.Model):
    name = models.ForeignKey('db1')
    title = models.CharField(max_length=100)
