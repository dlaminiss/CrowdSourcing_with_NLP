#code from https://gist.github.com/onyxfish/322906
"""
This files contains a class which is used to extract entity names
from the text given by the user in the form
"""
import nltk
import sys
#reload(sys)
#sys.setdefaultencoding("utf-8")
class EntityGetter(object):
    #entity_names = []
    def __init__(self):
        self.entity_names = []

    def extract_entity_names(self, t):
        global  entity_names
        entity_names = []
        if hasattr(t, 'label') and t.label:
            if t.label() == 'NE':
                entity_names.append(' '.join([child[0] for child in t]))
            #else:
            #    for child in t:
            #        entity_names.extend(extract_entity_names(child))
        return entity_names

    def tok_text(self, text1):
        global entity_names
        entity_names = []
        mlist = nltk.word_tokenize(text1)
        mlist = nltk.pos_tag(mlist)
        chunked_sentences = nltk.chunk.ne_chunk(mlist, binary = True)
        print(chunked_sentences)
        print(len(chunked_sentences))
        for tree in chunked_sentences:
            print(tree)
            #for entity_
        print(len(tree))

        """for tree in chunked_sentences:
            # Print results per sentence
            # print extract_entity_names(tree)
            entity_names.extend(self.extract_entity_names(tree))
            # Print all entity names
            #print entity_names
            # Print unique entity names
            print(entity_names)"""

        #print(mlist)
