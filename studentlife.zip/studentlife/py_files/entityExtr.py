"""This code was adapted from
https://marcobonzanini.com/2015/09/29/easy-text-analytics-with-the-dandelion-api-and-python/
"""
import requests
import json

def get_entities(sometext):
    wordsList = sometext.split()
    url1 = 'text=' + wordsList[0]
    for i in range(1, len(wordsList)):
        url1 = url1 + '%20' + wordsList[i]
    #url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types%2Cabstract%2Ccategories%2Clod%2Cimage&top_entities=1&token=9409135ab22a4c2f8c26fa04143e0ab3'
    url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types&token=9409135ab22a4c2f8c26fa04143e0ab3'
    response = requests.get(url)
    return response.json()

def print_entities(data):
    for annotation in data['annotations']:
        print("Entity found: %s" % annotation['spot'])

if __name__ == '__main__':
    #TESTING WITH THIS TEXT
    #mytext = 'Cardiff castle at the city centre are very beautiful places. The bay in cardiff is also beautiful.'
    #mytext = 'Cardiff castle is a very beautiful places'
    #mytext = 'go to tesco, they sell good chines food'
    mytext = 'i think you will like sophia gardens'
    #mytext = 'freedom church is very welcoming'
    #mytext = 'there is a nice cinema in queen street'
    #mytext ='Cardiff bay is beautiful'
    #mytext = 'go to old trafford my friend'
    #mytext = 'i enjoy a creamy cheese burger'
    mytext = 'i used to spend time in the millennium stadium'
    response = get_entities(mytext)
    print(json.dumps(response, indent=4))
    print_entities(response)
