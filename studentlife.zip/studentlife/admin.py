from django.contrib import admin
from .models import TourPlaces, TourComments, Db1, Db2, CuisineShops, UniHalls, UniHallsRatings, CuisineComments, Universities

# Register your models here.
admin.site.register(TourPlaces)
admin.site.register(TourComments)
admin.site.register(Db2)
admin.site.register(Db1)
admin.site.register(CuisineShops)
admin.site.register(CuisineComments)
admin.site.register(Universities)
admin.site.register(UniHalls)
admin.site.register(UniHallsRatings)
