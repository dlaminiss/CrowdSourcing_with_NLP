from django import forms

MY_CHOICES = (
    ('1', 'Art'),
    ('2', 'Architecture'),
    ('3', 'Cultural monuments'),
    ('4', 'Food and drink'),
    ('5', 'Historical site'),
    ('6', 'Local traditions'),
    ('7', 'Museums'),
    ('8', 'Music and drama'),
    ('9', 'Parks'),
)

CHOICES = (('1', 'Worst',), ('2', 'Not bad',), ('3', 'Moderate',), ('4', 'Better',), ('5', 'Best',))

AUDIENCE_CHOICE = (
    ('1', 'Postgraduate'),
    ('2', 'Undergraduate'),
    ('3', 'All'),
)

ROOM_TYPE = (
    ('1', 'Ensuite'),
    ('2', 'Shared bathroom'),
)

class TourismQuestionForm(forms.Form):
    town = forms.CharField(max_length=100)
    visit = forms.CharField(max_length=100)
    location = forms.CharField(max_length=100)
    entryPrice = forms.DecimalField(max_digits=5, decimal_places=2)
    #place_location = forms.CharField(max_length=500)
    typeOfPlace = forms.ChoiceField(choices=MY_CHOICES)
    comments = forms.CharField(widget=forms.Textarea, max_length = 1000)


class CuisinShopForm(forms.Form):
    town = forms.CharField(max_length=100)
    shop = forms.CharField(max_length=100)
    location = forms.CharField(max_length=100)
    cuisin = forms.CharField(max_length=100)
    university = forms.CharField(max_length=100)
    comments = forms.CharField(widget=forms.Textarea, max_length = 1000)

class testForm(forms.Form):
    question = forms.CharField(max_length=200)


class AccomodationForm(forms.Form):
    university = forms.CharField(max_length=100)
    rating_Value_for_money = forms.ChoiceField(widget=forms.RadioSelect, choices=CHOICES)
    rating_Cleanness = forms.ChoiceField(widget=forms.RadioSelect, choices=CHOICES)
    rating_Internet = forms.ChoiceField(widget=forms.RadioSelect, choices=CHOICES)
    rating_Location = forms.ChoiceField(widget=forms.RadioSelect, choices=CHOICES)
    rating_Social = forms.ChoiceField(widget=forms.RadioSelect, choices=CHOICES)
    comments = forms.CharField(widget=forms.Textarea, max_length = 1000)

class addHallsForm(forms.Form):
    university = forms.CharField(max_length=100)
    hall = forms.CharField(max_length=100)
    price = forms.DecimalField(max_digits=10, decimal_places=2)
    website = forms.URLField()
    audience = forms.ChoiceField(choices=AUDIENCE_CHOICE)
    roomtype = forms.ChoiceField(choices=ROOM_TYPE)
    period_start = forms.DateField()
    period_end = forms.DateField()
