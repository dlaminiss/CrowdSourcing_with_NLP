"""This files handles all urls of the studentlife app"""
from django.conf.urls import url
from . import views #from this folder import views
from studentlife.views import StudentlifeView, StudentlifeView2, addHallsView, tourismView, cuisinView, testFormView, testView, accommodationView


urlpatterns = [
    url(r'^$', views.homePage, name='home'),
    url(r'^index1/$', views.myLogico, name='index1'),
    url(r'^index2/$', views.tourismView, name='index2'),
    url(r'^index3/$', views.cuisinView, name='index3'),
    url(r'^index4/$', views.testFormView, name='index4'),
    #url(r'^index7/$', views.testView, name='index7'),
    url(r'^index5/$', views.testView, name='index5'),
    url(r'^index6/$', views.accommodationView, name='index6'),
    url(r'^index7/$', views.autocompleteView2, name='index7'),
    url(r'^index8/$', views.uniSearch, name='index8'),
    url(r'^index9/$', views.addHallsView, name = 'index9'),


    #url(r'^api/get_drugs/', 'myproject.main.view.get_drugs', name='get_drugs'),

    #url(r'^index2/?(?P<city>\d+)?/?$', views.tourismView, name='index2'),
]
