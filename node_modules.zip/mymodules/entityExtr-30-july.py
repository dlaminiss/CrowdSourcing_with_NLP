"""This code was adapted from
https://marcobonzanini.com/2015/09/29/easy-text-analytics-with-the-dandelion-api-and-python/
"""
import requests
import json
import nltk, re, pprint
from nltk import word_tokenize, pos_tag, ne_chunk
from nltk.tag.stanford import StanfordNERTagger
classifier = '/usr/share/stanford-ner/classifiers/english.all.3class.distsim.crf.ser.gz'
jar = '/usr/share/stanford-ner/stanford-ner.jar'
st = StanfordNERTagger(classifier,jar)

tagged_sentences = nltk.corpus.treebank.tagged_sents()

#tourism = ['Place', 'Location']

#returns a json file with information about Entities from dbpedia
def get_db_json(sometext, jsonType):
    wordsList = sometext.split()
    url1 = 'text=' + wordsList[0]
    for i in range(1, len(wordsList)):
        url1 = url1 + '%20' + wordsList[i]
    if jsonType == 'entities':
        url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types%2Cabstract%2Ccategories%2Clod%2Cimage&top_entities=1&token=9409135ab22a4c2f8c26fa04143e0ab3'
        #url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types&token=9409135ab22a4c2f8c26fa04143e0ab3'
        #response = requests.get(url)
        #return response.json()
    else:#getting sentiments
        #url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types%2Cabstract%2Ccategories%2Clod%2Cimage&top_entities=1&token=9409135ab22a4c2f8c26fa04143e0ab3'
        #url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=types&token=9409135ab22a4c2f8c26fa04143e0ab3'
        url = 'https://api.dandelion.eu/datatxt/sent/v1/?lang=en&' + url1 + '&token=9409135ab22a4c2f8c26fa04143e0ab3'
        #url =  'https://api.dandelion.eu/datatxt/nex/v1/?lang=en%20&' + url1 + '&include=categories&token=9409135ab22a4c2f8c26fa04143e0ab3'

    print(url)
    response = requests.get(url)
    return response.json()


def get_google_geocode(sometext):
    wordsList = sometext.split()
    url1 = 'address=' + wordsList[0]
    for i in range(1, len(wordsList)):
        url1 = url1 + '+' + wordsList[i]
    url = 'https://maps.googleapis.com/maps/api/geocode/json?' + url1 + '&key=AIzaSyDad03AjuOsJn_ZWs14WZ3q74YkdCV602c'
    response = requests.get(url)
    print(url)
    return response.json()


def get_annotations(data, i):
    return data['annotations'][i]


#returns list of entities found in the json file from dbpedia
def get_db_entityList(data):
    myEntities = []
    for annotation in data['annotations']:
        myEntities.append(annotation['spot'])
    return myEntities


#this function returns a list of types
def get_type(annotList):#takes in annotation list
    mlist = []
    mytypes = []
    if len(annotList['types'] != 0):
        mlist = annotList['types']
        templist = []
        for i in range(len(mlist)):
            #print(mlist[i])
            #for m in mlist[i]:
            mlist[i] = mlist[i][28:]
            templist.append(mlist[i])
            mytypes.append(templist[0])
            templist = []
        #print(mytypes)
        #print(mlist)
        return mytypes
    else:
        return mytypes #return an empty list

def get_catergory(annotList):
    catergory = []
    catergory = annotList['categories']
    for i in range(len(catergory)):
        catergory[i] = catergory[i].lower()
    return catergory

#returns a dictionary with entity as key and catergory as value
def get_tag(tagList, entityList):
    tourism = ['Place', 'Location']
    shops = ['Company', 'Organisation', 'Agent']
    category_dict = {}
    for i in range(len(entityList)):
        #entityList[i] = entityList[i].lower() #convert to lower cases
        if tourism[0] and tourism[1] in tagList[i]:
            category_dict[entityList[i]] = 'tourism'
        elif shops[0] and shops[1] and shops[2] in tagList[i]:
            category_dict[entityList[i]] = 'shops'
        elif 'cuisine' in tagList[i]:
            category_dict[entityList[i]] =tagList[0]
        else:
            category_dict[entityList[i]] = 'unknown'
    return category_dict

def get_Abstract(data):
    abstractList = []
    for annotation in data['annotations']:
        abstractList.append(annotation['abstract'])
    return abstractList

def get_Image(data):
    imageList = []
    for annotation in data['annotations']:
        imageList.append(annotation['image'])
    print(imageList)

if __name__ == '__main__':
    #TESTING WITH THIS TEXT
    mytext = 'Cardiff castle at the city centre are very beautiful places. The bay in cardiff is also beautiful. Tesco is also cool'
    #mytext = 'I used to buy north african food'
    #mytext = 'go to tesco, they sell good chines food'
    #mytext = 'i think you will like sophia gardens'
    #mytext = 'freedom church is very welcoming'
    #mytext = 'there is a nice cinema in queen street'
    #mytext ='Cardiff bay is beautiful'
    #mytext = 'go to old trafford my friend'
    #mytext = 'i enjoy a creamy cheese burger'
    #mytext = 'tesco is good i used to spend time in the millennium stadium'
    #mytext = 'north road cardiff'
    #mytext = 'Queen Street, Cardiff, United Kingdom
    #mytext = 'This place is beautiful and so peaceful. It glows with colourful falling leaves in autumn.'
    mytext = 'i used to buy Nigerian cuisine and south african cuisine from tesco, lidl and walmart'
    jsonType = 'entities'
    jsonType2 = 'sentiments'
    response = get_db_json(mytext, jsonType)
    myannot = get_annotations(response,2)
    #get_type(myannot)
    cat = get_catergory(myannot)
    print(cat)
    ent = get_db_entityList(response)
    #mydict = get_tag(catlist, ent)
    #print(json.dumps(response))
    #print(ent)
    #get_type(response)
    #print(catlist)
    #print(mydict)
    #print(response['annotations'][0]['categories'][0])
    #print((response['sentiment']['score'])*100)
    #response = get_google_geocode(mytext)
    #print(response['results'][0]['geometry']['location']['lng'])
    #print(response['results'][0]['address_components'][2]['types'])#['location']['lat'])
    #for item in response['results'][0]['address_components']:
    #    if item['types'][0] == 'postal_code':
    #        print(item['long_name'])#['short_name'])
    #print(len(response['results']))

    #print(response['results'][0]['geometry']['location']['lat'])
    #print(len(response))
    #typesL = get_type(response)
    #print('Printing types : ',typesL )
    #entityL = get_db_entityList(response)
    #print('Printing entities ',entityL)
    #dict_cat = get_tag(typesL, entityL)
    #print('Printing dictionary: ', dict_cat)
    #print(len(response))
    #print(json.dumps(response))
    #print(response['annotations'][0]['image']['full'])
    #print_entities(response)
    #get_Image(response)
    #list1 = get_type(response)
    #print(list1)
