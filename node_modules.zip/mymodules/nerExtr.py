import nltk, re, pprint
from nltk import word_tokenize, pos_tag, ne_chunk
from nltk.tag.stanford import StanfordNERTagger
classifier = '/usr/share/stanford-ner/classifiers/english.all.3class.distsim.crf.ser.gz'
jar = '/usr/share/stanford-ner/stanford-ner.jar'



tagged_sentences = nltk.corpus.treebank.tagged_sents()

#text1 = 'go to Tesco, they sell good food'
#text1 = 'freedom church is very welcoming'
#text1 = text1.lower()
#text1 = 'old trafford is one of the most beautiful places'
#text1 = 'there is a nice cinema in queen street'


def nonWikiEntityExtr(text):
    grammar = r"""
      NE: {<DT|PP\$>?<JJ>*<NN|NNP|NNS>*}   # chunk determiner/possessive, adjectives and nouns
          {<NN|NNP|NNS>*}"                # chunk sequences of proper nouns
    """
    cp = nltk.RegexpParser(grammar)
    tagged_sentences  = nltk.pos_tag(nltk.word_tokenize(text))
    result = cp.parse(tagged_sentences)
    #print(result)
    nps = []
    for tree in result:
        if hasattr(tree, 'label') and tree.label:
            if tree.label() == 'NE':
                tretupl = []
                for word in tree:
                    tretupl.append(word[0])
                nps.append(tretupl)
    nps2 = []
    for mlist in nps:
        nps3 = []
        str = mlist[0].lower()
        for i in range(1, len(mlist)):
            word = mlist[i].lower()
            str = str + ' ' + word
        nps2.append(str)
    sentence = word_tokenize(text)
    #print(st.tag(sentence))
    print()
    print(nps2)
    taggedNE = nltk.pos_tag(nps2)
    print(taggedNE)
    namedEnt = nltk.ne_chunk(taggedNE)
    #chunked_sentences = nltk.chunk.ne_chunk(tagged_sentences, binary = True)
    print(namedEnt)
    return (nps2)
