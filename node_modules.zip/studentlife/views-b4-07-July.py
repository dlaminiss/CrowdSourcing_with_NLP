#from django.shortcuts import render, HttpResponse
from django.views.generic import TemplateView
from studentlife.forms import QuestionsForm
from django.shortcuts import render
import nltk, re, pprint
from nltk.chunk import conlltags2tree, tree2conlltags
from nltk import word_tokenize, pos_tag, ne_chunk

# Create your views here.

"""this is a function-based view
    all it's saying at this point is return the string 'This is the home page'
    to the browser via HttpResponse"""

from mymodules.entityExtr import get_entities, print_entities

class StudentlifeView(TemplateView):
    template_name = 'studentlife/index1.html'

    def get(self, request):
        form = QuestionsForm()
        return render(request, self.template_name, {'form':form})

    def post(self, request):
        form = QuestionsForm(request.POST)
        if form.is_valid():
            text1 = form.cleaned_data['tour_place']
            response = get_entities(text1)
            nouns = []
            for annotation in response['annotations']:
                nouns.append(annotation['spot'])
                #print("Entity found: %s" % annotation['spot'])
            #ne_tree = ne_chunk(pos_tag(word_tokenize(text1)))
            #mlist = nltk.word_tokenize(text1)
            #mlist1 = nltk.pos_tag(mlist)
            #is_noun = lambda pos: pos[:2] == 'NN'
            #nouns = [word for (word, pos) in mlist1 if is_noun(pos)]

            form = QuestionsForm()
        args = {'form':form, 'text1':text1, 'nouns':nouns}
        return render(request, self.template_name, args)
