from django.shortcuts import render, HttpResponse, redirect
from django.views.generic import TemplateView
from studentlife.forms import TourismQuestionForm, CuisinShopForm, testForm, AccomodationForm, addHallsForm
from django.shortcuts import render
import nltk, json
from nltk.tag.stanford import StanfordNERTagger
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from studentlife.models import *
from django.http import JsonResponse


classifier = '/usr/share/stanford-ner/classifiers/english.all.3class.distsim.crf.ser.gz'
jar = '/usr/share/stanford-ner/stanford-ner.jar'
st = StanfordNERTagger(classifier,jar)
tagged_sentences = nltk.corpus.treebank.tagged_sents()
# Create your views here.

from mymodules.entityExtr import *
from mymodules.nerExtr import nonWikiEntityExtr
#from mymodules.triplesExtr import tourismTripleManager

def homePage(request):
    return render(request, 'studentlife/index1.html')

def questionsIndex(request):
    mylist = [5,9,6,7,8]
    form = TourismQuestionForm()
    args = {'mylist':mylist, 'form':form}
    print('PRINTING FROM INDEX 2')
    #html = '<h1>HELLOOOOOOOOOOOOOOO</h1>'
    #print(mylist)
    return render(request, 'studentlife/index2.html')
    #return HttpResponse('studentlife/indextest.html')

def myLogico(request):
    url1 = reverse('index2')
    url2 = reverse('index3')
    url3 = reverse('autocompleteView')
    url4 = reverse('index5')
    if request.method == "POST":
        btnId = request.POST['btnId']
        #city = request.POST['text1']#get entered city. To be used later for determining city strrets
        #args = {'city':city}
        #print('Your city is ', city)
        if (btnId == 'tourism'):
            print('redirecting to tourismview using ', btnId)
            #return HttpResponseRedirect(reverse('index2', args))
            #url = reverse(('index2'), kwargs={ 'city': city })
            return redirect(url1)

        elif (btnId == 'cuisin'):
            print('redirecting to cuisinview')
            return redirect(url2)

        elif (btnId == 'accomodation'):
            print("redirecting to accomodationview")
            return redirect(url4)

        else:
            print('MY BUTTON ID IS ', btnId)
            return redirect(url1)


#def followUPTourismView(request):

#university name search view
def uniSearch(request):
    template_name = 'studentlife/index4.html'
    if request.is_ajax():
        #print('HUUURRRAYYYY')
        value = request.GET.get('search', None)
        #print('PRINTING FROM ajax : ', value)
        with open('uniList.json') as data_file:
            data = json.load(data_file)
        list = []
        for dictn in data:
            astring = dictn['university_name']
            if astring.startswith(value):
                #print(astring)
                list.append(astring)
        data = {
            'list': list,
        }
        return JsonResponse(data)


def testView(request):
    template_name = 'studentlife/index2.html'
    if request.is_ajax():
        print('HUUURRRAYYYY')
        jsonType = 'entities'
        value = request.GET.get('search', None)
        response = get_db_json(value, jsonType)
        print('PRINTING FROM ajax : ', value)
        entityImage = response['annotations'][0]['image']['full']
        try:
            if TourPlaces.objects.get(place_name = value):
                a = TourPlaces.objects.get(place_name = value)
                location = a.full_address
                typeOfPlace = a.place_type
                data = {'location':location, 'typeOfPlace':typeOfPlace, 'entityImage':entityImage}
                return JsonResponse(data)

        except:
            b = CuisineShops.objects.get(shop_name = value)
            #print('Full address : ',a.full_address)
            locShop = b.shop_street
            print('Full address : ',locShop)
            data = {'locShop':locShop}
            return JsonResponse(data)
    else:
        return render(request, template_name)


def tourismView(request):
    template_name = 'studentlife/index2.html'
    template_name2 = 'studentlife/index3.html'
    form = TourismQuestionForm()
    if request.is_ajax():
        value = request.GET.get('search', None)
        print('PRINTING FROM ajax : ', value)
        queryset = TourPlaces.objects.filter(place_name__contains=request.GET.get('search', None))
        #print('QUERRYYYY ', len())
        list = []
        for i in queryset:
            list.append(i.place_name)
            #print('QUERRYYYY ', i.place_name)
        data = {
            'list': list,
        }
        #print('YEEEAAAAAAAAAHHHHHHHHHHH!!!!!!!!!1')
        return JsonResponse(data)
    elif request.method == 'GET':
        question = 'Thank you for choosing to give student tourism related advice.'
        return render (request, template_name, {'form':form, 'question':question})
    else:
        #request.method == 'POST'
        form = TourismQuestionForm(request.POST)
        if form.is_valid():
            town = form.cleaned_data['town']
            touristPlace = form.cleaned_data['visit']
            price = form.cleaned_data['entryPrice']
            placeLocation = form.cleaned_data['location']
            typeOfPlace = form.cleaned_data['typeOfPlace']
            comments = form.cleaned_data['comments']
            mdata  = [touristPlace, placeLocation, price]
            #print('YESSSS, I LIKE ',touristPlace)
            #print('TYPE OF PLACE IS ', typeOfPlace)
            jsonType = 'entities'
            response = get_db_json(touristPlace, jsonType) #getting dbpedia json file
            #print(response)
            #myEntities = get_db_entityList(response)
            #print('We have found ',len(myEntities),' entities')
            #print(myEntities)
            """if len(myEntities) == 0: #entities are unknown to dbpedia
                nonWikiList = nonWikiEntityExtr(touristPlace)
                print('My non wiki list ', nonWikiList)
                counter = 0;
                args = {'nonWikiList':nonWikiList, 'touristPlace':touristPlace, 'price':price, 'placeLocation':placeLocation, 'counter':counter}
                return render (request, template_name2, args)
            else:"""
            #myTypes  = get_type(response)
            #print(myTypes)
            #img = "https://en.wikipedia.org/wiki/Special:FilePath/Tesco_Logo.svg?width=300"
            entityDict = getALLDicts(response)
            print(entityDict)
            form = TourismQuestionForm()
            subj = []
            for item in entityDict.items():
                if item[1]=='tourism':
                    subj.append(item[0])
            #process address, post code and geo-location from google geocode
            geodata = get_google_geocode(placeLocation)
            address = geodata['results'][0]['formatted_address']
            lat = geodata['results'][0]['geometry']['location']['lat']
            lng = geodata['results'][0]['geometry']['location']['lng']
            postcode = ''
            for item in geodata['results'][0]['address_components']:
                if item['types'][0] == 'postal_code':
                    postcode = item['long_name']
            jsonType = 'sentiments' #get sentiments
            sentimetsJson = get_db_json(comments, jsonType)
            sentiment = (sentimetsJson['sentiment']['score'])*100 #convert to percentage
            a = TourPlaces(place_name = subj[0], full_address = address,
                place_type = typeOfPlace, geo_lat = lat, geo_lon = lng,
                post_code = postcode)

            try: #check if entity has already been saved to database
                if TourPlaces.objects.get(pk = subj[0]):
                        fkey = TourPlaces.objects.get(pk = subj[0])
                        b = TourComments(place_name = fkey, sentiments = sentiment, comments = comments,
                            town_name = town, entry_price = price)
                        b.save()
            except Tourism.DoesNotExist:
                a.save()
                fkey = TourPlaces.objects.get(place_name = a.place_name)
                b = TourComments(place_name = fkey, sentiments = sentiment, comments = comments,
                    town_name = town, entry_price = price)
                b.save()
            args = {'form':form}#, 'entityDict':entityDict}
            return render(request, template_name, args)


def cuisinView(request):
    template_name = 'studentlife/index4.html'
    form = CuisinShopForm()
    if request.is_ajax():
        value = request.GET.get('search', None)
        print('PRINTING FROM ajax : ', value)
        queryset = CuisineShops.objects.filter(shop_name__contains=request.GET.get('search', None))
        #print('QUERRYYYY ', len())
        list = []
        for i in queryset:
            list.append(i.shop_name)
            #print('QUERRYYYY ', i.place_name)
        data = {
            'list': list,
        }
        #print('YEEEAAAAAAAAAHHHHHHHHHHH!!!!!!!!!1')
        return JsonResponse(data)
    elif request.method == 'GET':
        question = 'Thank you for choosing to give regional cuisine related advice.'
        return render (request, template_name, {'form':form, 'question':question})
    else:
        #request.method == 'POST'
        form = CuisinShopForm(request.POST)
        if form.is_valid():
            town = form.cleaned_data['town']
            shop = form.cleaned_data['shop']
            cuisin = form.cleaned_data['cuisin']
            location = form.cleaned_data['location']
            comments = form.cleaned_data['comments']
            jsonType = 'entities'
            response1 = get_db_json(shop, jsonType) #getting dbpedia json file
            response2 = get_db_json(cuisin, jsonType) #getting dbpedia json file
            #myEntities = get_db_entityList(response)
            #myTypes  = get_type(response)
            #print('PRINTING SHOPS')
            entityDict1 = getALLDicts(response1)
            entityDict2 = getALLDicts(response2)
            print(entityDict1, ' ', entityDict2)
            geodata = get_google_geocode(location)
            address = geodata['results'][0]['formatted_address']
            lat = geodata['results'][0]['geometry']['location']['lat']
            lng = geodata['results'][0]['geometry']['location']['lng']
            postcode = ''
            for item in geodata['results'][0]['address_components']:
                if item['types'][0] == 'postal_code':
                    postcode = item['long_name']
            #form = TourismQuestionForm()
            #tourismTripleManager(entityDict, placeLocation, price
            cuisineArr = []
            shopArr = []

            for item in entityDict1.items():
                if item[1] == 'shops':
                    shopArr.append(item[0])

            for item in entityDict2.items():
                if 'cuisine' in item[1]:
                    cuisineArr.append(item[0])

            shp = shopArr[0]
            shp = shp.title()
            arr = []
            arr = address.split(',')
            shopname = shp + ' - ' + arr[0]
            print(shopname)
            print(cuisineArr)
            a = CuisineShops(shop_name = shopname, shop_street = location, geo_lon = lng, geo_lat = lat, shop_address = address, post_code = postcode)
            try:
                if CuisineShops.objects.get(pk = shopname):
                    fkey = CuisineShops.objects.get(shop_name = a.shop_name)
                    b = CuisineComments(cuisine_name = cuisineArr[0], shop_name = fkey, comments = comments, town_name = town)
                    b.save()
            except CuisineShops.DoesNotExist:
                a.save()
                fkey = CuisineShops.objects.get(shop_name = a.shop_name)
                b = CuisineComments(cuisine_name = cuisineArr[0], shop_name = fkey, comments = comments, town_name = town)
                b.save()

            args = {'form':form}# 'entityDict':entityDict}
            return render(request, template_name, args)



def testFormView(request):
    template_name = 'studentlife/testing.html'
    #template_name = 'studentlife/testingauto.html'
    form = testForm()
    if request.method == 'GET':
        args = {'form':form}
        return render(request, template_name, args)
    else:
        form = testForm(request.POST)
        if form.is_valid():
            location = form.cleaned_data['location']
        args = {'form':form, 'location':location}
        return render(request, template_name, args)


def accommodationView(request):
    template_name = 'studentlife/index5.html'
    form = AccomodationForm()
    args = {'form':form}
    if request.is_ajax():
        #queryset = UniHalls.objects.filter(hall_name__startswith=request.GET.get('search', None))
        print(queryset)
        list = []
        searchStr = ""
        for item in queryset:
            try:
                #uniquery = Universities.objects.filter(university_name = item.university_name)
                #searchStr = item.hall_name + item.university_name
                #fkey = uniquery.university_name
                list.append(item.hall_name)
                print(item.hall_name)
                print('FKEY ',item.university_name)
            except:
                print('searching...')
        data = {
            'list': list,
        }
        return JsonResponse(data)
    elif request.method =='GET':
        return render(request, template_name, args)
    elif request.method == 'POST':
        form = AccomodationForm(request.POST)
        if form.is_valid():
            university = form.cleaned_data['university']
            rating_value = form.cleaned_data['rating_Value_for_money']
            rating_value = ((int(rating_value))/5)*100
            rating_cleanness = form.cleaned_data['rating_Cleanness']
            rating_cleanness = ((int(rating_cleanness))/5)*100
            rating_loc = form.cleaned_data['rating_Location']
            rating_loc = ((int(rating_loc))/5)*100
            rating_internet = form.cleaned_data['rating_Internet']
            rating_internet = ((int(rating_internet))/5)*100
            rating_social = form.cleaned_data['rating_Social']
            rating_social = ((int(rating_Social))/5)*100
            comments = form.cleaned_data['comments']
            jsonType = 'sentiments' #get sentiments
            sentimetsJson = get_db_json(comments, jsonType)
            sentiment = (sentimetsJson['sentiment']['score'])*100 #convert to percentage
            #print('University is: ', university)
            #print('RATING ', rating_value, ' ', rating_internet, ' ', rating_cleanness, ' ', rating_internet, ' ', comments)
            #fkey = Universities.objects.get(university_name = university)
            #a = HallsRatings(value_for_money = rating_value, university_name = fkey, cleanness = rating_cleanness, internet = rating_internet, social = rating_social, location = rating_loc, commentSentiment = sentiment)
            #a.save()
            args = {'form':form}
        return render(request, template_name, args)

def addHallsView(request):
    template_name = 'studentlife/index6.html'
    if request.method == 'GET':
        form = addHallsForm()
        args = {'form':form}
        return render(request, template_name, args)
    elif request.method == 'POST':
        form = addHallsForm(request.POST)
        if form.is_valid():
            university = form.cleaned_data['university']
            hall = form.cleaned_data['hall']
            price = form.cleaned_data['price']
            web = form.cleaned_data['website']
            audience = form.cleaned_data['audience']
            startdate = form.cleaned_data['period_start']
            endate = form.cleaned_data['period_end']
            print('PRINTING', university, ' ', hall, ' ', price, ' ', web, ' ', audience)
            fkey = Universities.objects.get(university_name = university)
            hall = hall + ' ~ ' + university
            #a = UniHalls(hall_name = hall, university_name = fkey, price = price, period_start = startdate, period_end = endate, website = web)
            #a.save()
            args = {'form':form}
            return render(request, template_name, args)
        else:
            args = {'form':form}
            return render(request, template_name, args)
    else:
        args = {'form':form}
        return render(request, template_name, args)


def autocompleteView2(request):
    template_name = 'studentlife/index4.html'
    if request.is_ajax():
        queryset = TourPlaces.objects.filter(place_name__startswith=request.GET.get('search', None))
        list = []
        for i in queryset:
            list.append(i.place_name)
        data = {
            'list': list,
        }
        #data: ["blue", "green", "pink", "red", "yellow"]

        return JsonResponse(data)
    else:
        #request.method =='GET':
        return render(request, template_name)


def get_drugs(request):
    if request.is_ajax():
        q = request.GET.get('term', '')
        drugs = Tourism.objects.filter(place_name__icontains = q )[:20]
        results = []
        for drug in drugs:
            drug_json = {}
            #drug_json['id'] = drug.rxcui
            #drug_json['label'] = drug.short_name
            drug_json['value'] = drug.short_name
            results.append(drug_json)
        data = json.dumps(results)
    else:
        data = 'fail'
    mimetype = 'application/json'
    return HttpResponse(data, mimetype)


class StudentlifeView(TemplateView):
    template_name = 'studentlife/index1.html'

    def get(self, request):
        form = TourismQuestionForm()
        return render(request, self.template_name, {'form':form})

    def post(self, request):
        form = TourismQuestionForm(request.POST)
        if form.is_valid():
            text1 = form.cleaned_data['answer']
            jsonType = 'entities'
            response = get_db_json(text1, jsonType)
            myEntities = get_db_entityList(response)
            myTypes  = get_type(response)
            counter = len(myEntities)
            counter = [0,1,2]
            img = "https://en.wikipedia.org/wiki/Special:FilePath/Tesco_Logo.svg?width=300"
            #myEntities = [1,5,8,6,7]
            entityDict = get_tag(myTypes, myEntities)
            #entityDict = {'city centre': 'tourism', 'Tesco': 'shops', 'Cardiff castle': 'tourism'}
            form = TourismQuestionForm()
        args = {'form':form, 'text1':text1, 'myEntities':myEntities, 'myTypes':myTypes, 'entityDict':entityDict, 'counter':counter, 'img':img}
        return render(request, self.template_name, args)


class StudentlifeView2(TemplateView):
    template_name = 'studentlife/index2.html'
    def get(self, request):
        return render(request, self.template_name)
