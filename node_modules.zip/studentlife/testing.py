#to extract tourism triples. It takes the tourism subject, the location and the entry price
from . import models as mymodels

def tourismTripleManager(subjDict, location, price):
    subj = []
    for item in subjDict.items():
        if item[1]=='tourism':
            subj.append(item[0])
    triples = [subj[0], location, price]
    print(triples)

#b = Tourism(place_name = 'Sophia', place_location ='CF20 7TG', entry_price = 0)
#b.save()
