$(function(){
  //For getting CSRF token;
  //This function was adapted from https://impythonist.wordpress.com/2015/06/16/django-with-ajax-a-modern-client-server-communication-practise/
  function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie != '') {
          var cookies = document.cookie.split(';');
    for (var i = 0; i < cookies.length; i++) {
         var cookie = jQuery.trim(cookies[i]);
    // Does this cookie string begin with the name we want?
    if (cookie.substring(0, name.length + 1) == (name + '=')) {
      cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
       }
      }
    }
   return cookieValue;
  }

  //Prepare csrf token
  var csrftoken = getCookie('csrftoken');

  //$(document).on('submit', '#myform', function(e){
  $(".pic_btn").on('click', function(e){
    e.preventDefault();
    var btnId = $(this).attr('id');
    //alert(btnId);
    console.log(btnId + ' button yeah');
    $.ajax({
      type: 'POST',
      //url: "{% url 'index4' %}",
      url: '/studentlife/index2/',
      data:{'btnId':btnId, csrfmiddlewaretoken : csrftoken}
      success: function(){
        alert('SUCCESS')
    //}
    });
  });
});
