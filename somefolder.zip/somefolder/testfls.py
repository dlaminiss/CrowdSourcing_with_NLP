import EntityGetter
from EntityGetter import EntityGetter
entget = EntityGetter()
mytext = 'Cardiff Castle is a very beautiful place. Manchester United is winning'
entget.tok_text(mytext)
